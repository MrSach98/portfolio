


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
h3{
  text-algin: center;
}
input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
</head>
<body>

<h3>Registration</h3>

<div class="container">
   <form action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>" method="POST">
  <div class="row">
 
                <div class="form-group col-md-6">
                  <label for="name">Name</label>
                  <input type="text" name="name" placeholder="name" class="form-control" id="name" required>
                </div>
                <div class="form-group col-md-6">
                <label for="gender">Gender</label>
    <select id="gender" name="gender">
      <option value="male">MALE</option>
      <option value="female">FEMALE</option>
      <option value="other">OTHER</option>
    </select>
    </div>
                <div class="form-group col-md-6">
                  <label for="name"> Email</label>
                  <input type="text" class="form-control" placeholder="email" name="email" id="email" required>
                </div>
               
              <div class="form-group">
                <label for="name">Subject</label>
                <input type="text" class="form-control" placeholder="subject" name="subject" id="subject" required>
              </div>
              <div class="form-group">
                <label for="name">Mobile</label>
                <input type="text" class="form-control" placeholder="number" name="number" id="number" required>
              </div>
               <div class="form-group col-md-6">
                  <label for="name"> Current date</label>
                  <input type="text" class="form-control" placeholder="date" name="date" id="date" required>
                </div>
                 <div class="form-group col-md-6">
                  <label for="name"> Address</label>
                  <input type="text" class="form-control" placeholder="address" name="address" id="address" required>
                </div>
              <div class="form-group">
                <label for="name">Message</label>
                <textarea class="form-control" name="message" placeholder="message" rows="10" id="message" required></textarea>
              </div>
             
             
              <input type="submit" name="submit" value="Submit"  style="background-color: green">
              
    <a href = "curd.php">edit/delete</a></button>
              
  </form>
</div>
<?php

include 'include/db.php';
$db= new mysqli('localhost','root','','curd');
if(isset($_POST['submit']))
{
  $sql="insert into form(name,gender,email,subject,number,date,address,message)
  values('".$_POST['name']."','".$_POST['gender']."',
  
  '".$_POST['email']."','".$_POST['subject']."', '".$_POST['number']."', '".$_POST['date']."',
  '".$_POST['address']."','".$_POST['message']."')";
 
      
  mysqli_query($db,$sql);
  
  echo"data submited sucessfully";
}
?>


</body>
</html>


