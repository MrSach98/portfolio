


<?php
  $users_id = $_GET['id'];
 
include 'include/db.php';
$db= new mysqli('localhost','root','','curd');
$sql = "DELETE FROM form WHERE id = $users_id";
mysqli_query($db, $sql) or die("Query Unsucessful.");
echo "data deleted sucessfully";
mysqli_close($db);
header("Location: curd.php");

?>