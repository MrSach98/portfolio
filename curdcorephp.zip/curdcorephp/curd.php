
<html>
<style>
table, th, td {
  border: 1px solid;
}
</style>
    <body  style="background-color:lightgreen;">
        <table style="background-color:green;">
        <thead>
                    <tr>
                      <th>ID</th>                     
                      <th> Your Name</th>
                      <th> Your gender</th>
                      
					            <th> your Email </th>
                      <th> Your subject</th>
                                <th> your number </th>
                      <th> current date</th>
                      <th> Your address</th>
                      <th> your Message</th>
                      <th>operation</th>
                    </tr>
                  </thead>
<?php
			include 'include/db.php';
      $db= new mysqli('localhost','root','','curd');


                

                  $sql="select id ,name,gender,email,subject,number,date,address,message From form";
                  $result = $db->query($sql);   
				  while($row = $result->fetch_assoc()) {
					?>
                    <tr>
                      <td><?php echo $row["id"];?></td>
                      
                      <td><?php echo $row["name"];?></td>
                      <td><?php echo $row["gender"];?></td>
                      <td><?php echo $row["email"];?></td>
                      <td><?php echo $row["subject"];?></td>
                      <td><?php echo $row["number"];?></td>
                      <td><?php echo $row["date"];?></td>
                      <td><?php echo $row["address"];?></td>
                      <td><?php echo $row["message"];?></td>
<td> <button type="button" class="btn btn-primary"><a href = 'edit.php?id=<?php echo $row['id']; ?>'>edit</button> 
  <button type="button" class="btn btn-primary">
    <a href = 'delete.php?id=<?php echo $row['id']; ?>'>Delete</button></td>
                    </tr>
                  <?php
				  }
				  ?>

                </table>
                </body>	
</html>