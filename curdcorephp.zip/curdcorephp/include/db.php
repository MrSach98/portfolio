<?php

$servername ="localhost";
$username ="root";
$password ="";
$dbname ="curd";
$db= new mysqli($servername,$username,$password,$dbname);

?>