<!DOCTYPE HTML>
<html>
<style>
    h3{
        text-align: center;
    }
input[type=text], select { width: 100%;padding: 12px 20px; margin: 8px 0; display: inline-block; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box;
}
input[type=submit] {
  width: 100%;background-color: #4CAF50;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;
}
input[type=submit]:hover {background-color: #45a049;}
div { border-radius: 5px; background-color: #f2f2f2; padding: 20px;}
</style>
<body style="background-color:lightgreen;">

<?php

// Create connection
include 'include/db.php';
$db= new mysqli('localhost','root','','curd');
$id=$_GET['id'];
if(isset($_POST['update']))
	
{
	
$usql="Update form set name='".$_POST['name']."',gender='".$_POST['gender']."',
email='".$_POST['email']."', subject='".$_POST['subject']."',number='".$_POST['number']."', 
date='".$_POST['date']."',address='".$_POST['address']."',
message='".$_POST['message']. "'where id='$id'";

mysqli_query($db,$usql);
header('location:curd.php');
}
$sql = "SELECT id,name,gender,email,subject,number,date,address,message From form WHERE id=".$_GET['id'];
$data=mysqli_query($db,$sql);
$row=mysqli_fetch_array($data);
$result = $db->query($sql);

?>
<h3>student registation Form</h3>
<div>
<form action ="edit.php?id=<?=$id?>" method="post">
<label for="name" class="form-control"> Your Name</label>
<input value="<?php echo $row['name'] ?>" type="text" name="name" class="form-control" id="name">
<label for="name" class="form-control"> Your Gender</label>
<input value="<?php echo $row['gender'] ?>" type="text" name="gender" class="form-control" id="gender">
<label for="name" class="form-control"> Your Email</label>
<input value="<?php echo $row['email'] ?>" type="text" name="email" class="form-control" id="email">
<label for="name" class="form-control">Subject</label>
<input value="<?php echo $row['subject'] ?>" type="text" name="subject" class="form-control" id="subject">
<label for="name" class="form-control"> Your mobile</label>
<input value="<?php echo $row['number'] ?>" type="text" name="number" class="form-control" id="number">
<label for="name" class="form-control">Current Date</label>
<input value="<?php echo $row['date'] ?>" type="text" name="date" class="form-control" id="date">
<label for="name" class="form-control">Your Address </label>
<input value="<?php echo $row['address'] ?>" type="text" name="address" class="form-control" id="address">
<label for="name" class="form-control">Message</label>
<input value="<?php echo $row['message'] ?>" type="text" name="message" class="form-control"id="message" >
 <div class="text-center">
              <button type="submit" name="update" class="btn btn-primary">Update</button>
 <input type="reset" name="reset" value="Send Message">
              
            </div> 

  </form>
</div>

</body>
</html>

