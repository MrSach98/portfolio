
<?php
error_reporting(0);

$db = mysqli_connect('localhost','root','','group');
if($db)
{

}
else{
    echo"connection failed".mysqli_connect_error();
}
?>

