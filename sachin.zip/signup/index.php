

?>
<?php
require('frontend/include/db.php');
$query = "SELECT * FROM home,section_control,social_media,about,personal_info,skill,resume,portfolio,
contact,title,contact_form";
$run = mysqli_query($db,$query);
$user_data = mysqli_fetch_array($run);

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?=$user_data['page_title']?></title>
  <meta content="" name="<?=$user_data['description']?>">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="frontend/assets/img/favicon.png" rel="icon">
  <link href="frontend/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="frontend/assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="frontend/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="frontend/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="frontend/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="frontend/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="frontend/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="frontend/assets/css/style.css" rel="stylesheet">
  <style>

  </style>
  <!-- =======================================================
  * Template Name: iPortfolio
  * Updated: Mar 10 2023 with Bootstrap v5.2.3
  * Template URL: https://bootstrapmade.com/iportfolio-bootstrap-portfolio-websites-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body style="background:url('frontend/images/background1.jpg') top right no-repeat;">

  <!-- ======= Mobile nav toggle button ======= -->
  <i class="bi bi-list mobile-nav-toggle d-xl-none"></i>

  <!-- ======= Header ======= -->
  <header id="header">
    <div class="d-flex flex-column">

      <div class="profile">
        <img src="frontend/images/<?=$user_data['img']?>" alt="" class="img-fluid rounded-circle">
        <h1 class="text-light"><a href="index.html"><?=$user_data['title']?> </a></h1>
        <div class="social-links mt-3 text-center">
        <?php
if($user_data['showicons']){
  ?>
  <div class="social-links">
    
    <?php if($user_data['twitter']=''){?>    
    <a href="https://twitter.com/<?=$user_data['twitter']?>" class="twitter"><i class="icofont-twitter"></i></a>
    <?php 
}
    ?>

<?php if($user_data['facebook']=''){?>    
  <a href="https://facebook.com/<?=$user_data['facebook']?>" class="facebook"><i class="icofont-facebook"></i></a>

    <?php 
}
if($user_data['instagram']=''){
    ?>  
        <a href="https://instagram.com/<?=$user_data['instagram']?>" class="instagram"><i class="icofont-instagram"></i></a>
  <?php

}
if($user_data['linkedin']=''){
  ?>
        <a href="https://linkedin.com/<?=$user_data['linkedin']?>" class="linkedin"><i class="icofont-linkedin"></i></a>
   <?php
}
   ?>
      </div>
  <?php
}

?>
         
        </div>
      </div>

      <nav id="navbar" class="nav-menu navbar">
        <ul>
        <?php
if($user_data['home_section']){
?>
<li class="active"><a href="#header">Home</a></li>
<?php 
}
if($user_data['about_section']){
?>
          <li><a href="#about">About</a></li>
          <?php 
}
if($user_data['resume_section']){
?>
          <li><a href="#resume">Resume</a></li>
          <?php 
}
if($user_data['portfolio_section']){
  ?>
            <li><a href="#portfolio">portfolio</a></li>
            <?php 
  }
  
if($user_data['contact_section']){
  
?>
          <li><a href="#contact">Contact</a></li>
          <?php 
}
?>
        
        </ul>
        
      </nav><!-- .nav-menu -->
    
    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="hero-container" data-aos="fade-in">
    
 
      <h1><?=$user_data['home_title']?></h1>
      <p>I'm <span class="typed" data-typed-items="<?=$user_data['home-subtitle']?>"></span></p>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>About</h2>
</div>

        <div class="row">
          <div class="col-lg-4" data-aos="fade-right">
            <img src="frontend/images/<?=$user_data['about_image']?> " class="img-fluid" alt="">
          </div>
          <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
            <h3><i> <?=$user_data['about_title']?></i></h3>
            <p class="fst-italic">
            <?=$user_data['about_con']?>
            </p>
            <div class="row">
              <div class="col-lg-6">
                <ul>
                <?php
$query2 = "SELECT * FROM personal_info";
$run2 = mysqli_query($db,$query2);

while($personal_info = mysqli_fetch_array($run2)){
  ?>
<li><i class="icofont-rounded-right"></i> <strong><?=$personal_info['lavel']?> :</strong> <?=$personal_info['value']?></li>
  <?php
}
?>
               
                </ul>
              </div>
            </div>
            <p>
            <?=$user_data['about_subtitle']?>
</p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->



    <!-- ======= Skills Section ======= -->
    <section id="skills" class="skills section-bg">
      <div class="container">

        <div class="section-title">
        <h2>Skills</h2>
          
        </div>

        <div class="row skills-content">

          <div class="col-lg-12" data-aos="fade-up">

          <?php
$query3 = "SELECT * FROM skill";
$run3 = mysqli_query($db,$query3);

while($skill = mysqli_fetch_array($run3)){
  ?>
          <div class="progress">
            <span class="skill"><?=$skill['skill_name']?> <i class="val"><?=$skill['skill_level']?>%</i></span>
            <div class="progress-bar-wrap">
              <div class="progress-bar" role="progressbar" aria-valuenow="<?=$skill['skill_level']?>" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
          </div>
          <?php
}
          ?>
            </div>

          </div>

        </div>

      </div>
    </section><!-- End Skills Section -->

    <!-- ======= Resume Section ======= -->
    <section id="resume" class="resume">
      <div class="container">

        <div class="section-title">
          <h2>Resume</h2>
          

            <h3 class="resume-title">Education</h3>
            <?php
  
  $query4 = "SELECT * FROM resume";
  $run4 = mysqli_query($db,$query4);
  
  while($resume = mysqli_fetch_array($run4)){
    if($resume['type']=='education'){

    
    ?>


          <div class="resume-item">
            <h4><?=$resume['title']?></h4>
           
          
            <h5><?=$resume['time']?></h5>
            <p><em><?=$resume['org']?></em></p>
            <p><?=$resume['exp']?></p>
          </div>
          








 <?php
 }
  }
 ?>

 <button style="background-color: red" color:white> <a href="main sachin resume.docx"><i class="bi bi-download">download CV</i></a></button>
        </div>
        <div class="col-lg-6">
          <h3 class="resume-title">Professional Experience</h3>

          
   <?php   
   $query4 = "SELECT * FROM resume";
   $run4 = mysqli_query($db,$query4);    
          while($resume = mysqli_fetch_array($run4)){
    if($resume['type']=='company'){

    
    ?>


<div class="resume-item">
            <h4><?=$user_data['title']?></h4>
            <h5><?=$resume['time']?></h5>
            <p><em><?=$resume['org']?></em></p>
            <p><?=$resume['exp']?></p>
          </div>
 <?php
 }
}
 ?>
  
        </div>
      </div>
 
    </div>
  </section><!-- End Resume Section -->
    <!-- End Resume Section -->

    <!-- ======= Portfolio Section ======= -->
     <!-- ======= Portfolio Section ======= -->
  <section id="portfolio" class="portfolio">
    <div class="container">

      <div class="section-title">
        <h2>Portfolio</h2>
        <p>My Works</p>
      </div>

      <div class="row">
        <div class="col-lg-12 d-flex justify-content-center">
          
        </div>
      </div>

      <div class="row portfolio-container">
      <?php   
   $query5 = "SELECT * FROM portfolio";
   $run5 = mysqli_query($db,$query5);    
          while($port = mysqli_fetch_array($run5)){

    ?>
        <div class="col-lg-4 col-md-6 portfolio-item filter-app">
          <div class="portfolio-wrap">
            <img src="frontend/images/<?=$user_data['project_pic']?>" class="img-fluid" alt="">
            <div class="gallery-info">
              <h4><?=$user_data['project_name']?></h4>
              <p><?=$user_data['project_type']?></p>
              <div class="portfolio-links">
                <a href="frontend/images/<?=$user_data['project_pic']?>" data-gall="portfolioGallery" class="venobox" title="App 1"><i class="bx bx-plus"></i></a>
                <a href="<?=$user_data['project_link']?>" data-gall="portfolioDetailsGallery" data-vbtype="iframe" class="venobox" title="Portfolio Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>
        </div>
<?php
          }
?>
        
       

      </div>

    </div>
  </section><!-- End Portfolio Section -->
       
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2>Contact</h2>
          <p></p>
        </div>

        <div class="row" data-aos="fade-in">

          <div class="col-lg-5 d-flex align-items-stretch">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Home Town:</h4>
                <p><?=$user_data['home_town']?></p>
              </div>
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>current Location</h4>
                <p> <?=$user_data['location']?></p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p><?=$user_data['email']?></p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Call:</h4>
                <p><?=$user_data['phonenumber']?></p>
              </div>

              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14253.366409106893!2d83.16313035645267!3d26.733473009531725!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399139911ad67c3f%3A0x1c8ec8c044b49d7f!2sJogiya%20khol!5e0!3m2!1sen!2sin!4v1683375997093!5m2!1sen!2sin"  frameborder="0" style="border:0; width: 100%; height: 290px;" allowfullscreen></iframe>
            </div>

          </div>
        
          <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
            
            <form action="#" method="post" >
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="name">Name</label>
                  <input type="text" name="name" class="form-control" placeholder="enter your name"; id="name" required>
                </div>
                <div class="form-group col-md-6">
                  <label for="name"> Email</label>
                  <input type="email" class="form-control" name="email" placeholder="enter your email"; id="email" required>
                </div>
              </div>
              <div class="form-group">
                <label for="name">Subject</label>
                <input type="text" class="form-control" name="subject" placeholder="enter your subject"; id="subject" required>
              </div>
              <div class="form-group">
                <label for="name">Mobile</label>
                <input type="text" class="form-control" name="mobile" placeholder="enter your mobile number";id="mobile" required>
              </div>
              <div class="form-group">
                <label for="name">Message</label>
                <textarea class="form-control" name="message" rows="10" placeholder="enter your message";id="message" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              
              <div class="text-center"><input type="submit" name="submit" value="Submit" 
              style="background-color: green"> </div>
             
            
              
            </form>
           
          
            <?php
            if(isset($_POST['submit']))
            {
             $name    = $_POST['name'];
             $email   = $_POST['email'];
             $subject = $_POST['subject'];
             $mobile  = $_POST['mobile'];
             $message = $_POST['message'];
              $sql = "insert into contact_form(name,email,subject,mobile,message)
              values('$name','$email','$subject','$mobile','$message')";
             
                  
             $data = mysqli_query($db,$sql);
              if($data){
                echo"data submited sucessfully";
              }
              else{
                echo"failed";;
              }
              
            }
            
           
            ?>
            
            
           
            
            
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->
  
  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
   
      <div class="copyright">
        &copy; Copyright <strong><span>SACHIN</span></strong>
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/iportfolio-bootstrap-portfolio-websites-template/ -->
        Designed by <a href="https://bootstrapmade.com/">Sachin</a>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="frontend/assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="frontend/assets/vendor/aos/aos.js"></script>
  <script src="frontend/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="frontend/assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="frontend/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="frontend/assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="frontend/assets/vendor/typed.js/typed.min.js"></script>
  <script src="frontend/assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="frontend/assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="frontend/assets/js/main.js"></script>

</body>

</html>